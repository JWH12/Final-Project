import React from 'react'

function Manager() {
  return (
    <div>Manager</div>
  )
}

export default Manager