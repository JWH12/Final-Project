import React from 'react'

function Board() {
  return (
    <div>Board</div>
  )
}

export default Board