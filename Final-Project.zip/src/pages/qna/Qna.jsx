import React from 'react'

function Qna() {
  return (
    <div>Qna</div>
  )
}

export default Qna