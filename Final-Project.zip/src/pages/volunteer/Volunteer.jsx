import React from 'react'

function Volunteer() {
  return (
    <div>Volunteer</div>
  )
}

export default Volunteer